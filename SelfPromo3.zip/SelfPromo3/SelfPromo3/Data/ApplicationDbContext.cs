﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using SelfPromo.Models;
using SelfPromo3.Models;

namespace SelfPromo3.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public DbSet<Experience> Experiences { get; set; }
        public DbSet<Responsibility> Responsibilities { get; set; }
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<Responsibility>()
                .HasIndex(r => new { r.SequenceNumber, r.ExperienceId })
                .IsUnique();
            base.OnModelCreating(builder);       
        }
    }
}
