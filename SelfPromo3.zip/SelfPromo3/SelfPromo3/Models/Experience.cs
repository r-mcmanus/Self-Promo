﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using SelfPromo3.Models;

namespace SelfPromo.Models
{
    public class Experience
    {
        [Key]
        public int ExperienceId { get; set; }

        [Required]
        [MaxLength(100)]
        public string Company { get; set; } //= default;

        [MaxLength(100)]
        public string JobTitle { get; set; } //= default;

        [Required]
        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; } //= default;

        [DataType(DataType.Date)]
        public DateTime? EndDate { get; set; } //= default;

        [Required]
        [MaxLength(5000)]
        public string Description { get; set; } //= default;
        public List<Responsibility> Responsibilities { get; set; } //= default;
        public bool IsProfessional { get; set; } //= default;

        //public Experience()
        //{ }
    }
}
