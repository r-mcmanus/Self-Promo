﻿using SelfPromo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SelfPromo3.Models
{
    public class Responsibility
    {
        [Key]
        public int ResponsibilityId { get; set; }

        [Required]
        public int SequenceNumber { get; set; }

        [Required]
        [MaxLength(250)]
        public string Value { get; set; }
        [ForeignKey("Experience")]
        public int ExperienceId { get; set; }
        public Experience Experience { get; set; }

        //public Responsibility()
        //{ }
    }
}
