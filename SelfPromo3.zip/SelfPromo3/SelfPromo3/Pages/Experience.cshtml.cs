using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using SelfPromo.Models;
using SelfPromo3.Data;

namespace SelfPromo.Pages
{
    public class ExperienceModel : PageModel
    {
        public List<Experience> ProfessionalExperiences { get; set; } = new List<Experience>();
        public List<Experience> Activities { get; set; } = new List<Experience>();
        private ApplicationDbContext _context;
        public ExperienceModel(ApplicationDbContext context)
        {
            _context = context;
        }
        public void OnGet()
        {
            var profExp = _context.Experiences
                      .Include(x => x.Responsibilities)
                      .Where(x => x.IsProfessional == true)
                      .OrderByDescending(ex => ex.StartDate);
            this.ProfessionalExperiences.AddRange(profExp);

            foreach (var ex in this.ProfessionalExperiences)
            {
                ex.Responsibilities = ex.Responsibilities.OrderBy(r => r.SequenceNumber).ToList();
            }

            var act = _context.Experiences
                      .Include(x => x.Responsibilities)
                      .Where(x => x.IsProfessional == false)
                      .OrderByDescending(ex => ex.StartDate);
            this.Activities.AddRange(act);

            foreach (var ex in this.Activities)
            {
                ex.Responsibilities = ex.Responsibilities.OrderBy(r => r.SequenceNumber).ToList();
            }
            //Experience ex1 = new Experience
            //{
            //    Company = "Augusta University",
            //    JobTitle = "Tutor",
            //    StartDate = new DateTime(2018, 08, 01),
            //    EndDate = new DateTime(2018, 12, 01),
            //    Description = "Worked in the Academic Success Center at Augusta University as a Computer Science tutor.",
            //    Responsibilities = new List<string>(), 
            //    IsProfessional = true
            //};
            //ex1.Responsibilities.Add("Tutor for CS 1301 and 1302");
            //ex1.Responsibilities.Add("Also helped students with Web Dev, Operating Systems, and sometimes Python");
            //ex1.Responsibilities.Add("Seen students in ACS by walk-in and appointment");
            //ex1.Responsibilities.Add("Was an embedded tutor in Professor Weldon's 1301 class");
            //ex1.Responsibilities.Add("I saved a student from making an F (brought student to about a C)");

            //Experience ex2 = new Experience
            //{
            //    Company = "S & S Landscaping",
            //    JobTitle = "Landscaping",
            //    StartDate = new DateTime(2018, 05, 01),
            //    EndDate = new DateTime(2018, 08, 01),
            //    Description = "I cut grass.",
            //    Responsibilities = new List<string>(),
            //    IsProfessional = true
            //};
            //ex2.Responsibilities.Add("Mowing");
            //ex2.Responsibilities.Add("Weedeating");
            //ex2.Responsibilities.Add("Edging");
            //ex2.Responsibilities.Add("Hedging");
            //ex2.Responsibilities.Add("All of the other stuff that you don't want to do.");

            //Experience ex3 = new Experience
            //{
            //    Company = "Lowe's",
            //    JobTitle = "Lawn & Garden Associate",
            //    StartDate = new DateTime(2017, 03, 01),
            //    EndDate = new DateTime(2017, 07, 01),
            //    Description = "I worked in the garden center at Lowe's.",
            //    Responsibilities = new List<string>(),
            //    IsProfessional = true
            //};
            //ex3.Responsibilities.Add("Assist customers");
            //ex3.Responsibilities.Add("Help customers load their purchases into vehicles");
            //ex3.Responsibilities.Add("Replenish empty or diminishing stock");
            //ex3.Responsibilities.Add("Buggy runs (keep shoppping carts at entrances)");

            //Experience act1 = new Experience
            //{
            //    Company = "Augusta University ACM Club",
            //    JobTitle = "Guest",
            //    StartDate = new DateTime(2018, 11, 01),
            //    Description = "I went there once."
            //};

            //Experience act2 = new Experience
            //{
            //    Company = "Straw Hat Pirates",
            //    JobTitle = "Captain",
            //    StartDate = new DateTime(1999, 10, 01),
            //    Description = "I made this up."
            //};

            //ProfessionalExperiences.Add(ex1);
            //ProfessionalExperiences.Add(ex2);
            //ProfessionalExperiences.Add(ex3);
            //Activities.Add(act1);
            //Activities.Add(act2);
        }
    }
}
