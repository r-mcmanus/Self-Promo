﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SelfPromo3.Data;
using SelfPromo3.Models;

namespace SelfPromo3.Pages.Responsibilities
{
    public class CreateModel : PageModel
    {
        private readonly SelfPromo3.Data.ApplicationDbContext _context;
        //private static int exId;

        public CreateModel(SelfPromo3.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet(int? id)
        {
            ViewData["Flag"] = false;
            if (id == null)
            {
                ViewData["ExperienceId"] = new SelectList(_context.Experiences, "ExperienceId", "Company");
                return Page();
                //return NotFound();
            }

            //Responsibility = await _context.Responsibilities
            //    .Include(r => r.Experience).FirstOrDefaultAsync(m => m.ResponsibilityId == id);

            //if (Responsibility == null)
            //{
            //    return NotFound();
            //}
            
            ViewData["ExperienceId"] = id;//new SelectList(_context.Experiences, "ExperienceId", "Company");
            //exId = (int)id;
            ViewData["Flag"] = true;
            //if (Request.Headers["Referer"].ToString() != null)
            //{
            //    ViewData["Referer"] = Request.Headers["Referer"].ToString();
            //}

            return Page();
            //ViewData["ExperienceId"] = new SelectList(_context.Experiences, "ExperienceId", "Company");
            //return Page();
        }


        [BindProperty]
        public Responsibility Responsibility { get; set; }

        //public async Task<IActionResult> OnGetAsync(int? id)
        //{
        //    ViewData["Flag"] = false;
        //    if (id == null)
        //    {
        //        ViewData["ExperienceId"] = new SelectList(_context.Experiences, "ExperienceId", "Company");
        //        return Page();
        //        //return NotFound();
        //    }

        //    Responsibility = await _context.Responsibilities
        //        .Include(r => r.Experience).FirstOrDefaultAsync(m => m.ResponsibilityId == id);

        //    if (Responsibility == null)
        //    {
        //        return NotFound();
        //    }

        //    ViewData["ExperienceId"] = id;//new SelectList(_context.Experiences, "ExperienceId", "Company");
        //    ViewData["Flag"] = true;
        //    //if (Request.Headers["Referer"].ToString() != null)
        //    //{
        //    //    ViewData["Referer"] = Request.Headers["Referer"].ToString();
        //    //}
        //    return Page();

        //}
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            if (id != null)
                Responsibility.ExperienceId = (int)id;

            _context.Responsibilities.Add(Responsibility);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
