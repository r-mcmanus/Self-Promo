﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using SelfPromo3.Data;
using SelfPromo3.Models;

namespace SelfPromo3.Pages.Responsibilities
{
    public class DeleteModel : PageModel
    {
        private readonly SelfPromo3.Data.ApplicationDbContext _context;

        public DeleteModel(SelfPromo3.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Responsibility Responsibility { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Responsibility = await _context.Responsibilities
                .Include(r => r.Experience).FirstOrDefaultAsync(m => m.ResponsibilityId == id);

            if (Responsibility == null)
            {
                return NotFound();
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Responsibility = await _context.Responsibilities.FindAsync(id);

            if (Responsibility != null)
            {
                _context.Responsibilities.Remove(Responsibility);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
