﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using SelfPromo3.Data;
using SelfPromo3.Models;

namespace SelfPromo3.Pages.Responsibilities
{
    public class DetailsModel : PageModel
    {
        private readonly SelfPromo3.Data.ApplicationDbContext _context;

        public DetailsModel(SelfPromo3.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public Responsibility Responsibility { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Responsibility = await _context.Responsibilities
                .Include(r => r.Experience).FirstOrDefaultAsync(m => m.ResponsibilityId == id);

            if (Responsibility == null)
            {
                return NotFound();
            }
            return Page();
        }
    }
}
