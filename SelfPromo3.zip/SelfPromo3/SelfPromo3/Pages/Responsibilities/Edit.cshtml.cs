﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SelfPromo3.Data;
using SelfPromo3.Models;

namespace SelfPromo3.Pages.Responsibilities
{
    public class EditModel : PageModel
    {
        private readonly SelfPromo3.Data.ApplicationDbContext _context;

        public EditModel(SelfPromo3.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Responsibility Responsibility { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Responsibility = await _context.Responsibilities
                .Include(r => r.Experience).FirstOrDefaultAsync(m => m.ResponsibilityId == id);

            if (Responsibility == null)
            {
                return NotFound();
            }

            ViewData["ExperienceId"] = new SelectList(_context.Experiences, "ExperienceId", "Company");

            if (Request.Headers["Referer"].ToString() != null)
            {
                ViewData["Referer"] = Request.Headers["Referer"].ToString();
            }
            return Page();

        }

        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(Responsibility).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ResponsibilityExists(Responsibility.ResponsibilityId))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool ResponsibilityExists(int id)
        {
            return _context.Responsibilities.Any(e => e.ResponsibilityId == id);
        }
    }
}
