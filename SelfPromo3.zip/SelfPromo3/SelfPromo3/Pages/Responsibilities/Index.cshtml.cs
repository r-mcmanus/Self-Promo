﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using SelfPromo3.Data;
using SelfPromo3.Models;

namespace SelfPromo3.Pages.Responsibilities
{
    public class IndexModel : PageModel
    {
        private readonly SelfPromo3.Data.ApplicationDbContext _context;

        public IndexModel(SelfPromo3.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Responsibility> Responsibility { get;set; }

        public async Task OnGetAsync()
        {
            Responsibility = await _context.Responsibilities
                .Include(r => r.Experience).ToListAsync();
        }
    }
}
